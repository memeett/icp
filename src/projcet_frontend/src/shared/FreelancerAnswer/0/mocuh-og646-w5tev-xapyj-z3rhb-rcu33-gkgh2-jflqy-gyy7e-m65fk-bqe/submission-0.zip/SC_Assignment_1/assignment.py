
#Function
def USDtoIDR(a):
    return a*16185

#Input
nominal = 100

#If-Else
if nominal < 1:
    print("Convertion Invalid, Must Be Positive Number (Greater Than $0)")
    exit()
else:
    result = USDtoIDR(nominal) #Pemanggilan FUnction
    print(nominal, "USD is equal", result, "IDR") #Print Hasil

